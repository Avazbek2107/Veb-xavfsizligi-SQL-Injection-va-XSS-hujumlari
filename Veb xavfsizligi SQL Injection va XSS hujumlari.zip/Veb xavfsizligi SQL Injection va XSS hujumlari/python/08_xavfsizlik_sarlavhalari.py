"""
8-misol: Javobga xavfsizlik sarlavhalarini (HTTP headers) qo'shish va
cookie'ni to'g'ri sozlash. Har qanday freymvorkda shu g'oya ishlaydi.
"""
from http.cookies import SimpleCookie

XAVFSIZLIK_SARLAVHALARI = {
    # Skriptlar faqat o'z domenidan; inline skript va eval taqiqlanadi
    "Content-Security-Policy": "default-src 'self'; script-src 'self'; object-src 'none'; base-uri 'self'; frame-ancestors 'none'",
    "X-Content-Type-Options": "nosniff",          # MIME turini taxmin qilishni o'chiradi
    "Referrer-Policy": "strict-origin-when-cross-origin",
    "X-Frame-Options": "DENY",                    # Clickjacking'ga qarshi (eski brauzerlar uchun)
}


def sessiya_cookie(qiymat: str) -> str:
    c = SimpleCookie()
    c["sessiya"] = qiymat
    c["sessiya"]["httponly"] = True     # JS (document.cookie) o'qiy olmaydi -> XSS zarari kamayadi
    c["sessiya"]["secure"] = True       # faqat HTTPS orqali
    c["sessiya"]["samesite"] = "Strict" # boshqa saytlardan yuborilmaydi (CSRF)
    c["sessiya"]["path"] = "/"
    return c.output(header="Set-Cookie:")


if __name__ == "__main__":
    for k, v in XAVFSIZLIK_SARLAVHALARI.items():
        print(f"{k}: {v}")
    print(sessiya_cookie("a8f3c2e1d9"))
