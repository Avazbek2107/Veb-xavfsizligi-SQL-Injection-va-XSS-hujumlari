"""
7-misol: Oq ro'yxatga (allowlist) asoslangan HTML tozalovchi.
Foydalanuvchiga <b>, <i>, <a href> kabi xavfsiz teglarni ishlatishga ruxsat
berib, qolgan hamma narsani olib tashlaydi.
Real loyihalarda tayyor, sinovdan o'tgan kutubxonadan foydalaning (masalan, nh3 yoki bleach).
"""
import html
from html.parser import HTMLParser

RUXSAT_TEGLAR = {"b", "i", "u", "em", "strong", "p", "br", "ul", "ol", "li", "a", "code"}
RUXSAT_ATRIBUTLAR = {"a": {"href", "title"}}
RUXSAT_SXEMALAR = ("http://", "https://", "mailto:")
TASHLAB_YUBORISH = {"script", "style"}  # ichidagi matn bilan birga o'chiriladi


class Tozalovchi(HTMLParser):
    def __init__(self):
        super().__init__(convert_charrefs=True)
        self.natija, self.ochiq, self.yashirin = [], [], 0

    def handle_starttag(self, teg, atributlar):
        if teg in TASHLAB_YUBORISH:
            self.yashirin += 1
            return
        if teg not in RUXSAT_TEGLAR or self.yashirin:
            return
        xavfsiz = []
        for nom, qiymat in atributlar:
            if nom in RUXSAT_ATRIBUTLAR.get(teg, set()) and qiymat is not None:
                if nom == "href" and not qiymat.strip().lower().startswith(RUXSAT_SXEMALAR):
                    continue   # javascript: kabi sxemalarni bloklash
                xavfsiz.append(f' {nom}="{html.escape(qiymat, quote=True)}"')
        if teg == "a":
            xavfsiz.append(' rel="nofollow noopener"')
        self.natija.append(f"<{teg}{''.join(xavfsiz)}>")
        if teg != "br":
            self.ochiq.append(teg)

    def handle_endtag(self, teg):
        if teg in TASHLAB_YUBORISH:
            self.yashirin = max(0, self.yashirin - 1)
            return
        if teg in self.ochiq and not self.yashirin:
            while self.ochiq:
                t = self.ochiq.pop()
                self.natija.append(f"</{t}>")
                if t == teg:
                    break

    def handle_data(self, data):
        if not self.yashirin:
            self.natija.append(html.escape(data))

    def tozala(self, kiritish: str) -> str:
        self.feed(kiritish)
        self.close()
        self.natija.extend(f"</{t}>" for t in reversed(self.ochiq))
        return "".join(self.natija)


def tozala(s: str) -> str:
    return Tozalovchi().tozala(s)


if __name__ == "__main__":
    for s in [
        "<b>Salom</b> <i>dunyo</i>",
        "<script>alert(1)</script>Matn",
        '<a href="javascript:alert(1)">bos</a>',
        '<a href="https://example.com" onclick="x()">sayt</a>',
        '<img src=x onerror=alert(1)><p>abzats',
    ]:
        print(f"{s!r}\n   -> {tozala(s)!r}\n")
