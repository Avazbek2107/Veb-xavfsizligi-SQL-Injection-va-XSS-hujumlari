"""
5-misol: Mehmonlar kitobi veb-serveri (Stored XSS laboratoriyasi).
Ishga tushirish:
    python 05_xss_mehmonlar_kitobi.py          -> xavfsiz rejim
    python 05_xss_mehmonlar_kitobi.py zaif     -> zaif rejim (faqat lokal sinov!)
So'ng brauzerda oching: http://127.0.0.1:8000
Faqat standart kutubxona ishlatiladi.
"""
import html
import sys
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import parse_qs

ZAIF = len(sys.argv) > 1 and sys.argv[1] == "zaif"
XABARLAR = []   # oddiylik uchun xotirada saqlanadi


class Ishlovchi(BaseHTTPRequestHandler):
    def _javob(self, tana: str):
        self.send_response(200)
        self.send_header("Content-Type", "text/html; charset=utf-8")
        if not ZAIF:
            # Qo'shimcha himoya qatlami: ichki skriptlarni taqiqlovchi CSP
            self.send_header("Content-Security-Policy", "default-src 'self'; script-src 'self'")
            self.send_header("X-Content-Type-Options", "nosniff")
        self.end_headers()
        self.wfile.write(tana.encode("utf-8"))

    def do_GET(self):
        royxat = "".join(
            f"<li><b>{x if ZAIF else html.escape(x)}</b></li>" for x in XABARLAR
        )
        rejim = "ZAIF" if ZAIF else "XAVFSIZ"
        self._javob(f"""<!doctype html><meta charset="utf-8">
<title>Mehmonlar kitobi</title>
<h2>Mehmonlar kitobi ({rejim} rejim)</h2>
<form method="post"><input name="xabar" size="60"> <button>Yuborish</button></form>
<ul>{royxat}</ul>
<p>Sinab ko'ring: <code>&lt;img src=x onerror=alert(1)&gt;</code></p>""")

    def do_POST(self):
        uzunlik = int(self.headers.get("Content-Length", 0))
        maydon = parse_qs(self.rfile.read(uzunlik).decode("utf-8"))
        xabar = maydon.get("xabar", [""])[0][:500]   # uzunlikni cheklash
        if xabar:
            XABARLAR.append(xabar)
        self.send_response(303)
        self.send_header("Location", "/")
        self.end_headers()


if __name__ == "__main__":
    print(f"Rejim: {'ZAIF' if ZAIF else 'XAVFSIZ'}. Manzil: http://127.0.0.1:8000  (to'xtatish: Ctrl+C)")
    HTTPServer(("127.0.0.1", 8000), Ishlovchi).serve_forever()
