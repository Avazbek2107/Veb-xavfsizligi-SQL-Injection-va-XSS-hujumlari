"""
1-misol: SQL Injection'ga zaif login tizimi (faqat o'quv maqsadida!)
Ishga tushirish: python 01_sqli_zaif_login.py
Hech qanday tashqi kutubxona kerak emas (sqlite3 Python ichida bor).
"""
import sqlite3


def baza_yaratish():
    """Xotirada vaqtinchalik baza yaratib, foydalanuvchilarni qo'shamiz."""
    con = sqlite3.connect(":memory:")
    cur = con.cursor()
    cur.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, login TEXT, parol TEXT, rol TEXT)")
    cur.executemany(
        "INSERT INTO users (login, parol, rol) VALUES (?, ?, ?)",
        [("admin", "S3cr3t!", "administrator"),
         ("ali", "qwerty", "talaba"),
         ("vali", "12345", "talaba")],
    )
    con.commit()
    return con


def zaif_login(con, login, parol):
    # XATO: foydalanuvchi kiritgan matn to'g'ridan-to'g'ri SQL ga qo'shilmoqda
    sql = "SELECT id, login, rol FROM users WHERE login = '" + login + "' AND parol = '" + parol + "'"
    print("  Bajarilgan SQL:", sql)
    try:
        return con.execute(sql).fetchall()
    except sqlite3.Error as e:
        print("  SQL xatosi:", e)   # Xato matnini ko'rsatish ham ma'lumot sizdiradi!
        return []


if __name__ == "__main__":
    con = baza_yaratish()
    sinovlar = [
        ("Oddiy kirish",          "ali",                       "qwerty"),
        ("Noto'g'ri parol",       "ali",                       "xato"),
        ("Izoh bilan chetlash",   "admin' --",                 "nimadir"),
        ("Har doim rost shart",   "' OR '1'='1",               "' OR '1'='1"),
        ("UNION bilan o'g'irlash", "' UNION SELECT id, login, parol FROM users --", "x"),
    ]
    for nom, l, p in sinovlar:
        print(f"\n[{nom}]  login={l!r}  parol={p!r}")
        natija = zaif_login(con, l, p)
        print("  Natija:", natija if natija else "kirish rad etildi")
