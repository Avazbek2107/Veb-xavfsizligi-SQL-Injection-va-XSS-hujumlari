"""
4-misol: XSS qanday paydo bo'ladi va html.escape() uni qanday to'xtatadi.
Natija ikkita HTML fayl: zaif.html va xavfsiz.html (brauzerda ochib ko'ring).
"""
import html

izohlar = [
    "Ajoyib maqola, rahmat!",
    "<b>Qalin</b> matn",
    "<script>alert('XSS: ' + document.cookie)</script>",
    '<img src="x" onerror="alert(\'rasm orqali XSS\')">',
]


def sahifa(izohlar, ekranlash: bool) -> str:
    qatorlar = []
    for iz in izohlar:
        matn = html.escape(iz, quote=True) if ekranlash else iz   # asosiy farq shu yerda
        qatorlar.append(f"    <li>{matn}</li>")
    return ("<!doctype html>\n<meta charset='utf-8'>\n<h1>Izohlar</h1>\n<ul>\n"
            + "\n".join(qatorlar) + "\n</ul>\n")


if __name__ == "__main__":
    for iz in izohlar:
        print(f"{iz:<55} -> {html.escape(iz)}")
    open("zaif.html", "w", encoding="utf-8").write(sahifa(izohlar, ekranlash=False))
    open("xavfsiz.html", "w", encoding="utf-8").write(sahifa(izohlar, ekranlash=True))
    print("\nzaif.html va xavfsiz.html yaratildi. Ikkalasini brauzerda ochib solishtiring.")
