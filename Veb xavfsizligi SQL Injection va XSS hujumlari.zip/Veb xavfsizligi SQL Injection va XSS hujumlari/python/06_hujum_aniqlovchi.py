"""
6-misol: Imzolarga (signature) asoslangan oddiy hujum aniqlovchi (mini-WAF).
Algoritm:
  1) Kiritishni normallashtirish (URL decode, HTML entity decode, kichik harf)
  2) Har bir qoidani (regex) tekshirish va og'irlik ballarini yig'ish
  3) Ball chegaradan oshsa -> BLOKLASH, aks holda -> RUXSAT
Eslatma: WAF faqat qo'shimcha qatlam. Asosiy himoya - parametr va ekranlash.
"""
import html
import re
from urllib.parse import unquote_plus

QOIDALAR = [
    # (nom, turi, regex, ball)
    ("Izoh belgisi",          "SQLi", r"(--|#|/\*)",                                   2),
    ("Tautologiya OR 1=1",    "SQLi", r"\bor\b\s+['\"]?\w+['\"]?\s*=\s*['\"]?\w+",     4),
    ("UNION SELECT",          "SQLi", r"\bunion\b(\s+all)?\s+\bselect\b",              5),
    ("Stacked query",         "SQLi", r";\s*(drop|delete|insert|update|create)\b",     5),
    ("Vaqt funksiyasi",       "SQLi", r"\b(sleep|benchmark|pg_sleep|waitfor)\b",       4),
    ("Qo'shtirnoq yopilishi", "SQLi", r"'\s*(or|and)\b",                               3),
    ("Qo'shtirnoq + izoh",    "SQLi", r"'\s*(--|#|/\*)",                             3),
    ("<script> tegi",         "XSS",  r"<\s*script\b",                                 5),
    ("Hodisa atributi",       "XSS",  r"\bon\w+\s*=",                                  4),
    ("javascript: URL",       "XSS",  r"javascript\s*:",                               4),
    ("Xavfli teglar",         "XSS",  r"<\s*(iframe|svg|object|embed|img)\b",          2),
]
CHEGARA = 4


def normallashtirish(s: str) -> str:
    oldingi = None
    # Ikki marta kodlangan (double encoding) holatlar uchun bir necha marta decode
    while oldingi != s:
        oldingi = s
        s = html.unescape(unquote_plus(s))
    return re.sub(r"\s+", " ", s).lower()


def tahlil(kiritish: str):
    matn = normallashtirish(kiritish)
    topilgan = [(nom, tur, ball) for nom, tur, rx, ball in QOIDALAR if re.search(rx, matn)]
    jami = sum(b for _, _, b in topilgan)
    return ("BLOKLASH" if jami >= CHEGARA else "RUXSAT"), jami, topilgan


if __name__ == "__main__":
    namunalar = [
        "Toshkent shahri",
        "admin' --",
        "1 OR 1=1",
        "%27%20UNION%20SELECT%20login%2Cparol%20FROM%20users--",
        "<ScRiPt>alert(1)</script>",
        "&lt;img src=x onerror=alert(1)&gt;",
        "O'zbekiston",           # apostrof bor, lekin hujum emas
    ]
    for n in namunalar:
        qaror, ball, qoidalar = tahlil(n)
        print(f"{qaror:<9} ball={ball:<2} {n!r}")
        for nom, tur, b in qoidalar:
            print(f"           - [{tur}] {nom} (+{b})")
