"""
2-misol: Xuddi shu login, lekin parametrlangan so'rov va parol xeshlash bilan.
Ishga tushirish: python 02_sqli_himoya.py
"""
import hashlib
import hmac
import os
import re
import sqlite3


def parol_xesh(parol: str, tuz: bytes) -> str:
    # PBKDF2: parolni bazada ochiq holda saqlamaslik uchun
    return hashlib.pbkdf2_hmac("sha256", parol.encode(), tuz, 200_000).hex()


def baza_yaratish():
    con = sqlite3.connect(":memory:")
    con.execute("CREATE TABLE users (id INTEGER PRIMARY KEY, login TEXT UNIQUE, tuz BLOB, xesh TEXT, rol TEXT)")
    for login, parol, rol in [("admin", "S3cr3t!", "administrator"), ("ali", "qwerty", "talaba")]:
        tuz = os.urandom(16)
        con.execute("INSERT INTO users (login, tuz, xesh, rol) VALUES (?, ?, ?, ?)",
                    (login, tuz, parol_xesh(parol, tuz), rol))
    con.commit()
    return con


LOGIN_QOLIP = re.compile(r"^[a-zA-Z0-9_]{3,32}$")   # oq ro'yxat (allowlist)


def xavfsiz_login(con, login, parol):
    # 1-qatlam: kiritishni tekshirish
    if not LOGIN_QOLIP.fullmatch(login):
        return "Rad etildi: login formati noto'g'ri"
    # 2-qatlam: parametrlangan so'rov. ? o'rniga qiymat ALOHIDA yuboriladi
    qator = con.execute("SELECT id, tuz, xesh, rol FROM users WHERE login = ?", (login,)).fetchone()
    if qator is None:
        return "Login yoki parol noto'g'ri"
    uid, tuz, xesh, rol = qator
    # 3-qatlam: vaqt bo'yicha xavfsiz solishtirish
    if hmac.compare_digest(xesh, parol_xesh(parol, tuz)):
        return f"Xush kelibsiz! id={uid}, rol={rol}"
    return "Login yoki parol noto'g'ri"


if __name__ == "__main__":
    con = baza_yaratish()
    for l, p in [("ali", "qwerty"), ("admin' --", "x"), ("' OR '1'='1", "' OR '1'='1"), ("admin", "S3cr3t!")]:
        print(f"login={l!r:<22} -> {xavfsiz_login(con, l, p)}")

    # Validatsiyasiz ham parametr himoya qilishini ko'rsatamiz:
    print("\nFaqat parametr (validatsiyasiz):")
    print(con.execute("SELECT login FROM users WHERE login = ?", ("' OR '1'='1",)).fetchall(),
          "<- bo'sh ro'yxat, hujum ishlamadi")
