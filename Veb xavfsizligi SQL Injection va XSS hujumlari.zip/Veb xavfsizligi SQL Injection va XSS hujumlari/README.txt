VEB XAVFSIZLIGI — SQL Injection va XSS o'quv platformasi
=========================================================
Ishlab chiquvchi: Rejabaliyeva Pokiza Qulmamatovna

QANDAY OCHILADI
  index.html faylini ikki marta bosing (Chrome, Edge yoki Firefox).
  Internet shart emas, hammasi lokal ishlaydi.

TUZILMA
  index.html          - asosiy sahifa
  css/style.css       - dizayn
  js/content.js       - darslar matni, algoritmlar va testlar (tahrirlash shu yerda)
  js/app.js           - sahifa mantig'i va simulyatorlar
  js/kodlar.js        - python/ papkasidagi kodlar (avtomatik yaratiladi)
  img/                - chizmalar (SVG)
  python/             - 8 ta ishga tushiriladigan Python misol
  build_kodlar.py     - python/ fayllari o'zgarsa: python build_kodlar.py

KURS TARKIBI
  1. Veb xavfsizligi asoslari (2 dars)
  2. SQL Injection hujumlari (3 dars)
  3. Cross-Site Scripting / XSS (3 dars)
  4. Aniqlash va amaliyot (2 dars)
  + Python kodlar sahifasi va 15 savollik yakuniy test

PYTHON MISOLLAR
  cd python
  python 01_sqli_zaif_login.py
  python 05_xss_mehmonlar_kitobi.py zaif   (keyin brauzerda http://127.0.0.1:8000)

Barcha misollar faqat ta'lim maqsadida va o'z kompyuteringizda sinash uchun.
